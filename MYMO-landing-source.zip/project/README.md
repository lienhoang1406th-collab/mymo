# MYMO Landing Page

Mã nguồn landing page MYMO với branding tím và interactive bot Telly.

## Chạy local

Mở `index.html` trực tiếp trong trình duyệt, hoặc chạy:

```bash
python3 -m http.server 3000
```

Sau đó truy cập http://localhost:3000

## Cấu trúc

- `index.html`: giao diện landing page
- `styles.css`: CSS responsive và branding
- `script.js`: tương tác tabs, demo và bot
- `public/`: logo và favicon
- `dist/`: bản static đã copy để deploy
