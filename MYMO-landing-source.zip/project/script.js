const form = document.querySelector('#signup-form');
const email = document.querySelector('#email');
const formMessage = document.querySelector('#form-message');
const signupEndpoint = 'https://script.google.com/macros/s/AKfycby25Mr7HYjeLNMxIA5jaC3WytkscaqWEgAls63-OhbBVXlOQVlBQpg73D_rOkLN21qB5g/exec';

function track(eventName, parameters = {}) {
  if (typeof window.gtag === 'function') window.gtag('event', eventName, parameters);
}

form?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const normalizedEmail = email?.value.trim().toLowerCase();
  let alreadySaved = '';
  try { alreadySaved = window.localStorage.getItem('mymo_waitlist_email') || ''; } catch (_) {}
  if (normalizedEmail && normalizedEmail === alreadySaved) {
    formMessage.textContent = 'That email is already on the MYMO waitlist.';
    return;
  }
  if (!email?.value.trim() || !email.validity.valid) {
    formMessage.textContent = 'Add a valid email and we’ll save your place.';
    email?.focus();
    return;
  }

  const submitButton = form.querySelector('button[type="submit"]');
  if (submitButton) submitButton.disabled = true;
  formMessage.textContent = 'Saving your place…';

  try {
    await fetch(signupEndpoint, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
      body: new URLSearchParams({ email: email.value.trim(), source: 'MYMO landing page' }),
      keepalive: true
    });
    formMessage.textContent = 'You’re on the list — MYMO will be in touch soon.';
    track('signup_submitted', { method: 'landing_page' });
    form.reset();
  } catch (_) {
    formMessage.textContent = 'We couldn’t save that just now. Please try again.';
  } finally {
    if (submitButton) submitButton.disabled = false;
  }
});

const launcher = document.querySelector('#bot-launcher');
const dialog = document.querySelector('#mymo-dialog');
const closeButton = document.querySelector('#bot-close');
const botForm = document.querySelector('#bot-form');
const botInput = document.querySelector('#bot-input');
const botMessages = document.querySelector('#bot-messages');
const quickPrompts = document.querySelectorAll('[data-prompt]');
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const phaseOptions = document.querySelectorAll('[data-phase]');
const phaseCurrent = document.querySelector('#phase-current');
const phaseLabels = {
  menstrual: 'Menstrual · resting',
  follicular: 'Follicular · curious',
  ovulation: 'Ovulation · bright',
  luteal: 'Luteal · calm'
};
const emotionLabels = { listening: 'listening closely', caring: 'feeling caring', sparkly: 'feeling sparkly', curious: 'feeling curious' };
const emotionByPhase = { menstrual: 'caring', follicular: 'curious', ovulation: 'sparkly', luteal: 'listening' };
const phaseNotes = {
  menstrual: 'I’m in a softer, slower mood with you today.',
  follicular: 'I’m feeling curious and ready to notice what’s opening up.',
  ovulation: 'I’m feeling bright and sparkly—let’s notice what feels good.',
  luteal: 'I’m keeping things calm and cozy while we check in.'
};
function setEmotion(emotion) {
  const value = emotionLabels[emotion] ? emotion : 'listening';
  document.querySelectorAll('[data-companion=\"telly\"]').forEach((avatar) => {
    avatar.dataset.emotion = value;
    const art = avatar.querySelector('.telly-art');
    if (art) art.src = `public/telly-${value}.png`;
  });
  const label = document.querySelector('#telly-emotion-label');
  if (label) label.textContent = emotionLabels[value];
}
function setPhase(phase) {
  if (!phaseLabels[phase]) return;
  document.body.dataset.phase = phase;
  setEmotion(emotionByPhase[phase]);
  phaseOptions.forEach((option) => option.setAttribute('aria-pressed', String(option.dataset.phase === phase)));
  track('companion_phase_changed', { source: 'chat_demo' });
  if (phaseCurrent) phaseCurrent.textContent = phaseLabels[phase];
  if (botMessages?.children.length) appendMessage(phaseNotes[phase]);
}
setPhase('luteal');
phaseOptions.forEach((option) => option.addEventListener('click', () => setPhase(option.dataset.phase)));
let responseTimer;

const welcome = 'Hi, I’m Telly. You can tell me about your day in whatever words feel natural. I’ll help you notice context—not diagnose or judge.';
const responses = [
  { keys: ['low-energy', 'tired', 'exhausted', 'energy', 'drained'], text: 'That sounds like a low-energy kind of day. I’m noting the feeling as context for this demo. Has sleep, stress, or anything else been part of it?' },
  { keys: ['mood', 'happy', 'better', 'sad', 'low', 'anxious', 'emotional'], text: 'Thank you for sharing that mood shift. Small changes are worth noticing, especially alongside rest and cycle context. What else has today felt like?' },
  { keys: ['sleep', 'slept', 'restful', 'insomnia'], text: 'Sleep can be such a helpful piece of the picture. You can share what you remember in your own words, and MYMO will keep the conversation gentle.' },
  { keys: ['cramp', 'pain', 'headache', 'symptom', 'skin', 'bloat'], text: 'I’m sorry you’re dealing with that. I can help you describe the context, but I can’t diagnose or assess symptoms. If it’s severe, worrying, or persistent, please contact a qualified healthcare professional.' },
  { keys: ['stress', 'stressed', 'overwhelm', 'focus', 'busy'], text: 'That sounds like a lot to carry. We can simply make space for it here. Sometimes stress, sleep, energy, and cycle timing make a more useful picture together.' },
  { keys: ['notice', 'pattern', 'noticed', 'cycle', 'relationship'], text: 'In the clearly labelled sample on this page, energy often rises around cycle day 12 after a few restful nights. That is illustrative demo data—not your personal health record.' },
  { keys: ['good', 'great', 'social', 'bright', 'well', 'calm'], text: 'I love hearing a brighter check-in. What felt supportive today? Rest, connection, movement, food, or something else?' }
];

function appendMessage(text, who = 'them') {
  const bubble = document.createElement('div');
  bubble.className = `bot-message ${who}`;
  bubble.textContent = text;
  botMessages.appendChild(bubble);
  botMessages.scrollTop = botMessages.scrollHeight;
}

function getResponse(text) {
  const normalized = text.toLowerCase();
  const match = responses.find((item) => item.keys.some((key) => normalized.includes(key)));
  return match?.text || 'I’m here with you. Tell me a little more about what you noticed today—mood, energy, sleep, symptoms, or anything in between.';
}

function openBot() {
  dialog.hidden = false;
  launcher.setAttribute('aria-expanded', 'true');
  track('companion_opened', { source: 'landing_page' });
  if (!botMessages.children.length) appendMessage(welcome);
  window.setTimeout(() => botInput?.focus(), reducedMotion ? 0 : 120);
}
function closeBot() {
  dialog.hidden = true;
  launcher.setAttribute('aria-expanded', 'false');
  launcher.focus();
}
function sendMessage(rawText) {
  const text = rawText.trim();
  if (!text) return;
  appendMessage(text, 'you');
  const lower = text.toLowerCase();
  setEmotion(/cramp|pain|sad|low|stress|tired|overwhelm/.test(lower) ? 'caring' : /good|great|better|bright|happy/.test(lower) ? 'sparkly' : /what|notice|pattern|why|how/.test(lower) ? 'curious' : 'listening');
  const typing = document.createElement('div');
  typing.className = 'bot-message typing-message';
  typing.setAttribute('aria-label', 'Telly is typing');
  typing.innerHTML = '<span></span><span></span><span></span>';
  botMessages.appendChild(typing);
  botMessages.scrollTop = botMessages.scrollHeight;
  botInput.value = '';
  track('companion_message_sent', { source: 'chat_demo' });
  window.clearTimeout(responseTimer);
  responseTimer = window.setTimeout(() => { typing.remove(); appendMessage(getResponse(text)); window.setTimeout(() => setEmotion(emotionByPhase[document.body.dataset.phase] || 'listening'), reducedMotion ? 0 : 900); }, reducedMotion ? 0 : 360);
}

launcher?.addEventListener('click', () => (dialog.hidden ? openBot() : closeBot()));
closeButton?.addEventListener('click', closeBot);
botForm?.addEventListener('submit', (event) => { event.preventDefault(); sendMessage(botInput.value); });
quickPrompts.forEach((button) => button.addEventListener('click', () => { openBot(); sendMessage(button.dataset.prompt || ''); }));
document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && !dialog.hidden) closeBot(); });


const demoTabs = document.querySelectorAll('[data-demo-step]');
const demoPanels = document.querySelectorAll('[data-demo-panel]');
const demoChatBody = document.querySelector('#demo-chat-body');
const demoTyping = document.querySelector('#demo-typing');
const demoResponses = {
  "I've been feeling exhausted today.": 'That sounds like a lot to carry. I’ll keep this as gentle context for the demo—would a little extra preparation or rest help today?',
  'My period started this morning.': 'Thanks for telling me. I’ll place that in the sample cycle context, without assuming how you feel. What would support you today?',
  'I have a big presentation next Friday.': 'Got it. We can look at your sample patterns and make a little more room around an important day.'
};
function setDemoStep(step) {
  demoTabs.forEach((tab) => {
    const active = tab.dataset.demoStep === step;
    tab.classList.toggle('is-active', active);
    tab.setAttribute('aria-selected', String(active));
  });
  demoPanels.forEach((panel) => {
    const active = panel.dataset.demoPanel === step;
    panel.hidden = !active;
    panel.classList.toggle('is-active', active);
  });
  track('demo_step_viewed', { step });
}
demoTabs.forEach((tab) => tab.addEventListener('click', () => setDemoStep(tab.dataset.demoStep)));
demoTabs.forEach((tab) => tab.addEventListener('keydown', (event) => {
  if (event.key !== 'ArrowRight' && event.key !== 'ArrowLeft') return;
  event.preventDefault();
  const tabs = [...demoTabs];
  const current = tabs.indexOf(tab);
  const next = tabs[(current + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length];
  next.focus();
  setDemoStep(next.dataset.demoStep);
}));
document.querySelectorAll('[data-demo-prompt]').forEach((button) => button.addEventListener('click', () => {
  const text = button.dataset.demoPrompt || '';
  if (!demoChatBody) return;
  demoChatBody.querySelectorAll('.demo-chat-bubble.user,.demo-chat-bubble.reply').forEach((node) => node.remove());
  const user = document.createElement('div');
  user.className = 'demo-chat-bubble user';
  user.textContent = text;
  demoChatBody.insertBefore(user, demoTyping);
  if (demoTyping) demoTyping.hidden = false;
  window.setTimeout(() => {
    if (demoTyping) demoTyping.hidden = true;
    const reply = document.createElement('div');
    reply.className = 'demo-chat-bubble telly reply';
    reply.textContent = demoResponses[text] || 'I’m here with you. Let’s notice what feels useful in this moment.';
    demoChatBody.appendChild(reply);
    track('demo_prompt_selected', { source: 'experience_demo' });
  }, reducedMotion ? 0 : 650);
}));
const savedWaitlistEmail = () => { try { return window.localStorage.getItem('mymo_waitlist_email') || ''; } catch (_) { return ''; } };
const originalFormHandler = form;
if (originalFormHandler) {
  const observer = new MutationObserver(() => {
    if (formMessage?.textContent.includes('You’re on the list')) {
      try { window.localStorage.setItem('mymo_waitlist_email', email.value.trim().toLowerCase()); } catch (_) {}
    }
  });
  observer.observe(formMessage, { childList: true, characterData: true, subtree: true });
}

const revealTargets = document.querySelectorAll('.problem, .method, .conversation, .insight, .final-cta');
if (!reducedMotion && 'IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries, instance) => {
    entries.forEach((entry) => { if (entry.isIntersecting) { entry.target.classList.add('reveal'); instance.unobserve(entry.target); } });
  }, { threshold: 0.12 });
  revealTargets.forEach((target) => observer.observe(target));
} else revealTargets.forEach((target) => target.classList.add('reveal'));

const waReplay = document.querySelector('#wa-replay');
const waChat = document.querySelector('#wa-chat');
let waTimers = [];
function replayWhatsApp() {
  if (!waChat) return;
  waTimers.forEach((timer) => window.clearTimeout(timer));
  waTimers = [];
  const bubbles = [...waChat.querySelectorAll('.wa-bubble')];
  const sync = waChat.querySelector('.wa-sync');
  const typingIndicators = [...waChat.querySelectorAll('.wa-typing')];
  [...bubbles, sync].forEach((item) => { if (item) item.classList.remove('is-visible'); });
  typingIndicators.forEach((item) => { item.hidden = true; });
  bubbles.forEach((item, index) => {
    if (index > 0 && typingIndicators[index - 1]) {
      waTimers.push(window.setTimeout(() => { typingIndicators[index - 1].hidden = false; }, 120 + index * 500));
    }
    waTimers.push(window.setTimeout(() => {
      if (typingIndicators[index - 1]) typingIndicators[index - 1].hidden = true;
      item.classList.add('is-visible');
    }, 300 + index * 500));
  });
  if (sync) waTimers.push(window.setTimeout(() => sync.classList.add('is-visible'), 300 + bubbles.length * 500));
  track('whatsapp_demo_replayed', { source: 'whatsapp_preview' });
}
waReplay?.addEventListener('click', replayWhatsApp);
window.setTimeout(replayWhatsApp, reducedMotion ? 0 : 450);

document.querySelectorAll('[data-insight]').forEach((button) => button.addEventListener('click', () => {
  document.querySelectorAll('[data-insight]').forEach((item) => item.classList.remove('is-active'));
  button.classList.add('is-active');
  const copy = {
    energy: '<b>Sample pattern:</b> Your energy sometimes dips around cycle day 21 in this illustrative dataset.',
    sleep: '<b>Sample pattern:</b> Better sleep appears before higher-energy days in this illustrative dataset.',
    mood: '<b>Sample pattern:</b> Mood varies across recent cycles; MYMO would keep the context nuanced.'
  };
  const takeaway = document.querySelector('#insight-takeaway');
  if (takeaway) takeaway.innerHTML = copy[button.dataset.insight] || copy.energy;
  const tooltip = document.querySelector('.chart-tooltip');
  if (tooltip) tooltip.innerHTML = button.dataset.insight === 'sleep' ? 'Restful sleep appears here <span>sample day 8</span>' : button.dataset.insight === 'mood' ? 'Mood varies here <span>sample day 20</span>' : 'Energy often dips here <span>sample day 21</span>';
  track('insight_sample_selected', { insight: button.dataset.insight });
}));

const loggingCard = document.querySelector('#logging-card');
loggingCard?.addEventListener('click', () => loggingCard.classList.toggle('is-dismissed'));
loggingCard?.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); loggingCard.classList.toggle('is-dismissed'); } });

const heroPhone = document.querySelector('.hero .phone-shell');
if (heroPhone && !reducedMotion && 'IntersectionObserver' in window) {
  let heroStarted = false;
  const heroObserver = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting && !heroStarted) { heroStarted = true; heroPhone.classList.add('conversation-live'); }
  }, { threshold: .35 });
  heroObserver.observe(heroPhone);
}

const heroSequence = {
  welcome: document.querySelector('#hero-welcome'),
  typing: document.querySelector('#hero-typing'),
  user: document.querySelector('#hero-user-message'),
  tags: document.querySelector('#hero-tags'),
  reply: document.querySelector('#hero-reply'),
  hero: document.querySelector('.hero')
};
let heroSequenceTimer;
let heroSequenceStarted = false;
function heroWait(ms, callback) { heroSequenceTimer = window.setTimeout(callback, reducedMotion ? 0 : ms); }
function resetHeroSequence() {
  [heroSequence.welcome, heroSequence.user, heroSequence.tags, heroSequence.reply].forEach((item) => item?.classList.remove('is-shown'));
  if (heroSequence.typing) heroSequence.typing.hidden = true;
  heroSequence.hero?.classList.remove('hero-checkin-saved');
}
function runHeroSequence() {
  if (!heroSequence.welcome) return;
  window.clearTimeout(heroSequenceTimer);
  resetHeroSequence();
  heroWait(450, () => {
    heroSequence.welcome.classList.add('is-shown');
    heroWait(950, () => {
      if (heroSequence.typing) heroSequence.typing.hidden = false;
      heroWait(1050, () => {
        if (heroSequence.typing) heroSequence.typing.hidden = true;
        heroSequence.user?.classList.add('is-shown');
        heroWait(760, () => {
          heroSequence.tags?.classList.add('is-shown');
          heroWait(1050, () => {
            heroSequence.reply?.classList.add('is-shown');
            heroSequence.hero?.classList.add('hero-checkin-saved');
            heroWait(4200, runHeroSequence);
          });
        });
      });
    });
  });
}
if (heroSequence.welcome) {
  document.body.classList.add('hero-sequence-ready');
  if (reducedMotion) [heroSequence.welcome, heroSequence.user, heroSequence.tags, heroSequence.reply].forEach((item) => item?.classList.add('is-shown'));
  else if ('IntersectionObserver' in window) {
    const heroSequenceObserver = new IntersectionObserver((entries, observer) => { if (entries[0].isIntersecting && !heroSequenceStarted) { heroSequenceStarted = true; runHeroSequence(); observer.disconnect(); } }, { threshold: .3 });
    const heroSection = document.querySelector('.hero'); if (heroSection) heroSequenceObserver.observe(heroSection);
  } else { heroSequenceStarted = true; runHeroSequence(); }
}

const openHero = {
  stage: document.querySelector('.hero-open-space'),
  telly: document.querySelector('#hero-telly-main'),
  welcome: document.querySelector('#hero-open-welcome'),
  typing: document.querySelector('#hero-open-typing'),
  user: document.querySelector('#hero-open-user'),
  userText: document.querySelector('#hero-open-user-text'),
  tracking: document.querySelector('#hero-open-tracking'),
  reply: document.querySelector('#hero-open-reply')
};
const openUserCopy = "I've been feeling a little tired today.";
let openHeroTimer;
let openHeroStarted = false;
function openHeroWait(ms, callback) { openHeroTimer = window.setTimeout(callback, reducedMotion ? 0 : ms); }
function resetOpenHero() {
  [openHero.welcome, openHero.user, openHero.tracking, openHero.reply].forEach((item) => item?.classList.remove('is-visible'));
  openHero.telly?.classList.remove('is-reacting');
  if (openHero.typing) openHero.typing.hidden = true;
  if (openHero.userText) openHero.userText.textContent = '';
}
function runOpenHero() {
  if (!openHero.stage) return;
  window.clearTimeout(openHeroTimer);
  resetOpenHero();
  openHeroWait(350, () => {
    openHero.welcome?.classList.add('is-visible');
    openHeroWait(950, () => {
      if (openHero.typing) openHero.typing.hidden = false;
      openHeroWait(1050, () => {
        if (openHero.typing) openHero.typing.hidden = true;
        openHero.user?.classList.add('is-visible');
        let index = 0;
        const typeNext = () => {
          if (!openHero.userText) return;
          openHero.userText.textContent = openUserCopy.slice(0, index);
          index += 1;
          if (index <= openUserCopy.length) openHeroTimer = window.setTimeout(typeNext, reducedMotion ? 0 : 32);
          else openHeroWait(450, () => {
            openHero.telly?.classList.add('is-reacting');
            openHeroWait(700, () => {
              openHero.tracking?.classList.add('is-visible');
              openHeroWait(900, () => {
                openHero.reply?.classList.add('is-visible');
                openHeroWait(4200, runOpenHero);
              });
            });
          });
        };
        typeNext();
      });
    });
  });
}
if (openHero.stage) {
  document.body.classList.add('open-hero-ready');
  if (reducedMotion) {
    openHero.welcome?.classList.add('is-visible');
    openHero.user?.classList.add('is-visible');
    openHero.userText.textContent = openUserCopy;
    openHero.tracking?.classList.add('is-visible');
    openHero.reply?.classList.add('is-visible');
  } else if ('IntersectionObserver' in window) {
    const openHeroObserver = new IntersectionObserver((entries, observer) => {
      if (entries[0].isIntersecting && !openHeroStarted) { openHeroStarted = true; runOpenHero(); observer.disconnect(); }
    }, { threshold: .25 });
    openHeroObserver.observe(document.querySelector('.hero') || openHero.stage);
  } else { openHeroStarted = true; runOpenHero(); }
}

const nopeCard = document.querySelector('#logging-card');
if (nopeCard && 'IntersectionObserver' in window) {
  const nopeObserver = new IntersectionObserver((entries, observer) => {
    if (entries[0].isIntersecting) { nopeCard.classList.add('nope-ready'); observer.disconnect(); }
  }, { threshold: .3 });
  nopeObserver.observe(nopeCard);
} else if (nopeCard) nopeCard.classList.add('nope-ready');

const patternsChart = document.querySelector('#insights');
if (patternsChart && 'IntersectionObserver' in window) {
  const patternsObserver = new IntersectionObserver((entries, observer) => {
    if (entries[0].isIntersecting) { patternsChart.classList.add('chart-live'); observer.disconnect(); }
  }, { threshold: .2 });
  patternsObserver.observe(patternsChart);
} else if (patternsChart) patternsChart.classList.add('chart-live');

const predictionTabs = [...document.querySelectorAll('.prediction-tab')];
const predictionViews = [...document.querySelectorAll('.prediction-view')];
predictionTabs.forEach((tab) => tab.addEventListener('click', () => {
  const key = tab.dataset.prediction;
  predictionTabs.forEach((item) => { const active = item === tab; item.classList.toggle('is-active', active); item.setAttribute('aria-selected', String(active)); });
  predictionViews.forEach((view) => { view.hidden = view.id !== `prediction-${key}`; view.classList.toggle('is-active', view.id === `prediction-${key}`); });
}));
